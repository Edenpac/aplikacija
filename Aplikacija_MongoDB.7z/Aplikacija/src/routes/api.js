var Oseba = require('../models/oseba');

module.exports = function(router) {
    router.post('/', function(req, res) {
        var oseba = new Oseba();
        oseba.Ime = req.body.Ime;
        oseba.Priimek = req.body.Priimek;
        oseba.Naslov = req.body.Naslov;
        oseba.Starost = req.body.Starost;
        oseba.save();
        res.send('User created');
    });
    return router;
}