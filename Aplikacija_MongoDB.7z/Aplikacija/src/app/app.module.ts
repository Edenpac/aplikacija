import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OsebaDataComponent } from '../oseba-data/oseba-data.component';
import { InfoComponent } from '../info/info.component';
import { DataService } from '../data.service';
import { enableProdMode } from '@angular/core';
import {TableModule} from 'primeng/table';
import { HttpClientModule } from '@angular/common/http';
import {ButtonModule} from 'primeng/button';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ConfirmationService} from 'primeng/api';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import { DialogComponent } from '../dialog/dialog.component';



enableProdMode();

@NgModule({
  declarations: [
    AppComponent,
    OsebaDataComponent,
    InfoComponent,
    DialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TableModule,
    HttpClientModule,
    ButtonModule,
    ConfirmDialogModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    FormsModule,
    DialogModule
  ],
  providers: [DataService,ConfirmationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
