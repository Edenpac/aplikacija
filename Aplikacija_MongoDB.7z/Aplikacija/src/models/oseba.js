var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var osebaSchema = new Schema({
    _id:String,
    Ime: { type: String, required: true },
    Priimek: { type: String, required: true },
    Naslov: { type: String, required: true },
    Starost: { type: Number, required: true },
});

module.exports = mongoose.model('Oseba', osebaSchema);