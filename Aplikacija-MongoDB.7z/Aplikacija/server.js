const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mysql = require('mysql');
var morgan = require('morgan');
//var cors = require('cors');
//var fs = require('fs');
var mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/Aplikacija', { useMongoClient: true, promiseLibrary: require('bluebird') })
    .then(() => console.log('connection succesful'))
    .catch((err) => console.error(err));


apppp.use(morgan('dev'));
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
//app.use(cors());
//app.options('*', cors);
app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
    next();
})

const povezi = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'aplikacija'
});

povezi.connect((err) => {
    if (!err)
        console.log('DB povezava uspešna');
    else
        console.log('DB ni uspelo povezati! \n Error : ' + JSON.stringify(err, undefined, 2));

});

app.listen(3000, function() {});

app.get('/:id', function(req, res) {
    const st = Number((req.params.id).substring(1));
    var p = (st > 0) ? " where Id=" + st : "";
    povezi.query("SELECT * FROM osebe" + p, function(err, results) {
        if (err) throw err;
        else {
            return res.send(results);
        }
    });
});


app.put('/osebe/', function(req, res) {
    res.header('Content-Type', 'application/json');
    var q = req.body[0];
    var sql = "UPDATE osebe SET Ime = '" + q.Ime + "',Priimek='" + q.Priimek + "',Naslov='" + q.Naslov + "',Starost=" + q.Starost + " WHERE Id=" + q.Id;
    povezi.query(sql, function(err, result) {
        if (err) throw err;
    });
})

app.post('/', function(req, res) {
    res.header('Content-Type', 'application/json');
    var q = req.body;
    var sql = "Insert into osebe values(null,'" + q.Ime + "','" + q.Priimek + "','" + q.Naslov + "','" + q.Starost + "')";
    povezi.query(sql, function(err, result) {
        if (err) throw err;
    });
});


app.delete('/:id', (req, res) => {
    const st = Number((req.params.id).substring(1));
    povezi.query('DELETE FROM osebe WHERE Id = ?', [st], (err, rows, fields) => {
        if (!err) {
            res.send(req.params.Id);
        } else
            console.log(err);
    })
});