import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OsebaDataComponent } from '../oseba-data/oseba-data.component';
import { InfoComponent } from '../info/info.component';

const routes: Routes = [
  { path: '', component: OsebaDataComponent },
  { path: 'info/:id', component: InfoComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
