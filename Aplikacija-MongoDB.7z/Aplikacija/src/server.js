const express = require("express");
const app = express();
var mongoose = require("mongoose")
    .set('debug', true)
    .set('useUnifiedTopology', true)
    .set('useFindAndModify', false);
const bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    res.header(
        "Access-Control-Allow-Headers",
        "Content-Type, Authorization, Content-Length, X-Requested-With"
    );
    next();
});

var osebaSchema = mongoose.Schema({
    Ime: { type: String, required: true },
    Priimek: { type: String, required: true },
    Naslov: { type: String, required: true },
    Starost: { type: Number, required: true }
});

var osModel = mongoose.model('oseba', osebaSchema);

mongoose.connect("mongodb://localhost:27017/aplikacija", { useNewUrlParser: true }, function (err) {
    if (err) console.log("Ni povezve z DB: " + err);
    else console.log("Povezava z DB Uspešna");
});

app.listen(3000);

app
    .get("/:id", function (req, res) {
        var st = req.params.id.substring(1);
        if (st == "0") {
            osModel.find(function (err, aplikacija) {
                if (err) console.log(err);
                res.json(aplikacija);
            });
        }
        else {
            osModel.findById(st, function (err, ros) {
                if (err) console.log(err);
                else {
                    var tab = [];
                    tab.push(ros);
                    res.json(tab);
                }
            });
        }
    })

    .post("/", function (req, res) {
        osModel.create(req.body, function (err, post) {
            if (err) return next(err);
        })
    })

    .put('/:id', function (req, res) {
        var st = req.params.id.substring(1);
        osModel.findByIdAndUpdate(st, req.body, function (err, dobil) {
            if (err) console.log(err);
        })
    })

    .delete('/:id', function (req, res) {
        var st = req.params.id.substring(1);
        osModel.findByIdAndRemove(st, req.body, function (err, dobil) {
            if (err) console.log(err);
        })
    });
