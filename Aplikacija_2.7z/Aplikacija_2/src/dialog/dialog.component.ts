import { Component, OnInit } from "@angular/core";
import { Oseba, DataService } from "src/data.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-dialog",
  templateUrl: "./dialog.component.html",
  styleUrls: ["./dialog.component.css"]
})
export class DialogComponent implements OnInit {
  model: Oseba;
  submitted = false;

  onSubmit() {
      var osebo = Object.assign({}, this.model);
      this.submitted = true;
      this.data.prikaz = false;
      this.data.dodaj(osebo).subscribe(() => {
        this.router.navigate(["/"]).then(() => {
          window.location.reload();
        });
      });
      
  }

  constructor(public data: DataService, private router: Router) {}

  ngOnInit() {
    this.model = {} as Oseba;
  }
}
