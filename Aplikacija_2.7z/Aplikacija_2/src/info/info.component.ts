import { Component, OnInit, OnDestroy } from "@angular/core";
import { DataService, Oseba } from "../data.service";
import { Router, ActivatedRoute } from "@angular/router";
import { ConfirmationService } from "primeng/api";

@Component({
  selector: "app-info",
  templateUrl: "./info.component.html",
  styleUrls: ["./info.component.css"]
})
export class InfoComponent implements OnInit, OnDestroy {
  copyOseb: Oseba;
  id: String;

  constructor(
    public data: DataService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private potrdi2: ConfirmationService
  ) {
    this.id = activatedRoute.snapshot.url[1].path;
  }
  osebe: Oseba[];

  ngOnInit() {
    this.data.dobi(this.id).subscribe(osebe => (this.osebe = osebe));
  }

  onRowEditInit(oseba: Oseba) {
    this.copyOseb = { ...oseba };
  }

  disableSaveButton(vrsta: Oseba) {
    if (
      vrsta.Ime === "" ||
      vrsta.Priimek === "" ||
      vrsta.Naslov === "" ||
      vrsta.Starost < 1
    ) {
      return true;
    }
    return false;
  }

  onRowEditCancel() {
    this.osebe[0] = this.copyOseb;
    delete this.copyOseb;
  }

  potrdi() {
    this.potrdi2.confirm({
      message: "Ali želite izbrisati uporabnika " + this.osebe[0].Ime + "?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        this.izbrisi();
        this.router.navigate(["/"]).then(() => {
          window.location.reload();
        });
      }
    });
  }

  posodobi() {
    this.data.posodobi(this.osebe[0]).subscribe(data => {
      console.log(data);
    });
  }

  izbrisi() {
    var l = this.osebe[0]._id;
    this.data.izbris(l).subscribe(() => {
      console.log(l), err => console.log(err);
    });
  }

  ngOnDestroy() {
    this.data.prikaz = false;
  }
}
