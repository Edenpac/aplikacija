import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OsebaDataComponent } from './oseba-data.component';

describe('OsebaDataComponent', () => {
  let component: OsebaDataComponent;
  let fixture: ComponentFixture<OsebaDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OsebaDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OsebaDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
