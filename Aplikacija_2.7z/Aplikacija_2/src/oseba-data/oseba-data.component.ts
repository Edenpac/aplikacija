import { Component, OnInit, OnDestroy } from "@angular/core";
import { DataService, Oseba } from "../data.service";
import { Router } from "@angular/router";
import { ConfirmationService } from "primeng/api";

@Component({
  selector: "app-oseba-data",
  templateUrl: "./oseba-data.component.html",
  styleUrls: ["./oseba-data.component.css"]
})
export class OsebaDataComponent implements OnInit, OnDestroy {
  osebe: Oseba[];

  constructor(
    public data: DataService,
    private pot: Router,
    private potrdi2: ConfirmationService
  ) {}

  potrdi(oseba:Oseba) {
    this.data.osebe = [oseba];
    this.potrdi2.confirm({
      message:
        "Ali želite izbrisati uporabnika " + this.data.osebe[0].Ime + "?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        console.log("Test1");
        this.izbrisi();
      }
    });
  }

  ngOnInit() {
    this.data.dobi("0").subscribe(osebe => (this.osebe = osebe));
  }

  onClick(id: String) {
    this.pot.navigate(["/info", id]);
  }

  izbrisi() {
    var l = this.data.osebe[0]._id;
    this.data.izbris(l).subscribe(() => {
      console.log(l), err => console.log(err);
    });
    window.location.reload();
  }

  ngOnDestroy() {
    this.data.prikaz = false;
  }
}
