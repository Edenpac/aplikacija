import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

export class Oseba {
  Id: number;
  Ime: string;
  Priimek: string;
  Naslov: string;
  Starost: number;
}

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})


export class DataService {
 
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client error:', errorResponse.error.message);
    }
    else {
      console.error('Server error ', errorResponse.error.message);
    }
    return throwError('Something bad happened; please try again later.');
  };


  izbris(id): Observable<void> {
    const url = 'http://127.0.0.1:3000/:' + id;
    return this.http.delete<void>(url, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  dodaj(oseba: Oseba): Observable<Oseba> {
    return this.http.post<Oseba>('http://127.0.0.1:3000/', oseba, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  constructor(private http: HttpClient) { }
  prikaz:boolean=false;
  Id: number;
  Ime: string;
  Priimek: string;
  Naslov: string;
  Starost: number;
  osebe: Oseba[];








}

