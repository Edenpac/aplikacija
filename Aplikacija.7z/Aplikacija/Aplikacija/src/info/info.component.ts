import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService, Oseba } from '../data.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css'],
})

export class InfoComponent implements OnInit, OnDestroy {

  copyOseb: Oseba;
  model: Oseba;
  id: number

  constructor(public data: DataService, private http: HttpClient, private activatedRoute: ActivatedRoute,private router:Router,  private potrdi:ConfirmationService) {
    this.id = Number(activatedRoute.snapshot.url[1].path);
  }
  osebe: Oseba[];

  ngOnInit() {
    this.osebe = this.data.osebe;
    if (this.data.osebe == undefined) {
      this.http.get<any>("http://localhost:3000/:" + this.id)
        .toPromise()
        .then(res => <Oseba[]>res)
        .then(data => { return data; })
        .then(osebe => this.osebe = osebe);
    }

    this.model = {} as Oseba;
  }

  onRowEditInit(oseba: Oseba) {
    this.copyOseb = { ...oseba };
  }

  onRowEditSave(oseba: Oseba) {
    if (oseba.Starost > 0) {
      delete this.copyOseb;
    }
  }

  onRowEditCancel() {
    this.osebe[0] = this.copyOseb;
    delete this.copyOseb;
  }

  dodaj(osebo: Oseba) {
    osebo = Object.assign({}, this.model);
    this.data.dodaj(osebo)
      .subscribe((data: Oseba) => {
        console.log(data)
      });
  }

  confirm1() {
    this.potrdi.confirm({
        message: 'Ali želite izbrisati uporabnika '+ this.osebe[0].Ime+'?',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.izbrisi();
            this.router.navigate(['/']).then(() => {
              window.location.reload();
        })
    }
  });
}

  posodobi() {
    const headers = new HttpHeaders()
      .set('Authorization', 'my-auth-token')
      .set('Content-Type', 'application/json');
    this.http.put('http://127.0.0.1:3000/osebe/', this.osebe, {
      headers: headers
    })
      .subscribe(data => {
        console.log(data);
      });
  };

  izbrisi() {
    var l = this.data.osebe[0].Id;
    this.data.izbris(JSON.stringify(l))
      .subscribe(() => {
        console.log(l),
          (err) => console.log(err);
      })
  };

  ngOnDestroy() {
    this.data.prikaz = false;
  }

  /*
  dodaj(){
    var oseb:Oseba=this.model;
    const headers = new HttpHeaders()
    .set('Authorization', 'my-auth-token')
    .set('Content-Type', 'application/json');
  this.http.post('http://127.0.0.1:3000/osebe/',oseb, {
    headers: headers
  })
    .subscribe(data => {
      console.log(JSON.stringify(data));
    });
  };
  
  izbrisi() {
    var l = this.data.osebe[0].Id;
    this.data.izbris(JSON.stringify(l))
      .subscribe(()=> {
        console.log(l),
        (err)=>console.log(err);
      })
    };*/




}





