import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService, Oseba } from '../data.service';
import { HttpClient} from "@angular/common/http";
import{Router} from '@angular/router';
import { Message, ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-oseba-data',
  templateUrl: './oseba-data.component.html',
  styleUrls: ['./oseba-data.component.css'],

})
export class OsebaDataComponent implements OnInit,OnDestroy {
   
  osebe: Oseba[];

  constructor(public data: DataService, private http: HttpClient, private pot:Router, private potrdi:ConfirmationService) { 
  }

  confirm1() {
    this.potrdi.confirm({
        message: 'Ali želite izbrisati uporabnika '+ this.data.osebe[0].Ime+'?',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.izbrisi();
        }
    });
}
  ngOnInit() {
    this.polni();
  }

  onClick(id:number){
    this.pot.navigate(['/info',id]);
  }

  polni() {
    this.http.get<any>("http://localhost:3000/:0")
      .toPromise()
      .then(res => <Oseba[]>res)
      .then(data => { return data; })
      .then(osebe => this.osebe = osebe);
  }

  izberiOseba(oseba: Oseba) {
    this.data.osebe = [oseba];
    //event.preventDefault;
  }

  izbrisi() {
    var l = this.data.osebe[0].Id;
    this.data.izbris(JSON.stringify(l))
      .subscribe(() => {
        console.log(l),
          (err) => console.log(err);
      })
      window.location.reload();
  };

  ngOnDestroy() {
    this.data.prikaz=false;
  }

}
