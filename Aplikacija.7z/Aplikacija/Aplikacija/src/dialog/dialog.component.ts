import { Component, OnInit } from '@angular/core';
import { Oseba, DataService } from 'src/data.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  model: Oseba;

  submitted = false;

  onSubmit() {
    this.submitted = true;
    this.data.prikaz = false;
    this.router.navigate(['/']).then(() => {
      window.location.reload();
    });
  }

  constructor(public data: DataService, private router: Router, private http: HttpClient) { }

  ngOnInit() {
    this.model = {} as Oseba;
  }

  dodaj() {
    var osebo = Object.assign({}, this.model);
    this.data.dodaj(osebo)
      .subscribe((data: Oseba) => {
        console.log(data)
      });
  }

}
